import React from 'react'

export default function Showcase(){
  return (
    <section className="section-card">
    </section>
  )
}
